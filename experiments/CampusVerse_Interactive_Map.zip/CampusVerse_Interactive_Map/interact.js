
/*
  CAMPUS VERSE INTERACTIVE MAP
  Edit the data in this file to add your own photos and descriptions.
*/

/* --------------------------------------------------
   1. ACADEMIC BLOCK INFORMATION
   -------------------------------------------------- */

const academicInfo = {
  /*
    Put your own image here.

    Example:
    photo: "assets/academic-block.jpg"

    Keep photo: "" if you want the blank photo box.
  */
  photo: "",

  description:
    "",

  direction:
    ""
};

/* Text shown for the two floors that are not interactive yet. */
const floorText = {
  ground:
    "Write your Ground Floor information here.",

  first:
    "Write your First Floor information here."
};

/* --------------------------------------------------
   2. SECOND FLOOR ROOM INFORMATION
   --------------------------------------------------
   Change only the description text.
   The room names and map positions can stay unchanged.
*/

const roomData = {
  isbn: {
    title: "I.S.B.N. Lab",
    description: "Write the description of I.S.B.N. Lab here."
  },

  idea: {
    title: "AICTE IDEA Lab",
    description: "Write the description of AICTE IDEA Lab here."
  },

  robotics: {
    title: "Robotics Lab",
    description: "Write the description of Robotics Lab here."
  },

  tutorial306: {
    title: "Tutorial Room 306",
    description: "Write the description of Tutorial Room 306 here."
  },

  tutorial305: {
    title: "Tutorial Room 305",
    description: "Write the description of Tutorial Room 305 here."
  },

  class308: {
    title: "Class Room 308",
    description: "Write the description of Class Room 308 here."
  },

  class307: {
    title: "Class Room 307",
    description: "Write the description of Class Room 307 here."
  },

  class319: {
    title: "Class Room 319",
    description: "Write the description of Class Room 319 here."
  },

  class320: {
    title: "Class Room 320",
    description: "Write the description of Class Room 320 here."
  },

  room325: {
    title: "Room 325",
    description: "Write the description of Room 325 here."
  },

  rnd321: {
    title: "R&D Space - Room 321",
    description: "Write the description of R&D Space here."
  },

  unknown322: {
    title: "Unknown - Room 322",
    description: "Write the description here if you later identify Room 322."
  },

  lecture304: {
    title: "Lecture Hall - Room 304",
    description: "Write the description of Lecture Hall 304 here."
  },

  lecture323: {
    title: "Lecture Hall - Room 323",
    description: "Write the description of Lecture Hall 323 here."
  },

  electronic302: {
    title: "Electronic Circuit Lab - Room 302",
    description: "Write the description of Electronic Circuit Lab here."
  },

  programming301: {
    title: "Computer Programming Lab - Room 301",
    description: "Write the description of Computer Programming Lab here."
  },

  vlsi303: {
    title: "VLSI And Embedded Lab - Room 303",
    description: "Write the description of VLSI And Embedded Lab here."
  },

  electrical315: {
    title: "Electrical Room - Room 315",
    description: "Write the description of Electrical Room here."
  },

  lift324: {
    title: "Lift Lobby - Room 324",
    description: "Write the description of Lift Lobby here."
  }
};

/* --------------------------------------------------
   3. ELEMENTS
   -------------------------------------------------- */

const academicModal = document.getElementById("academicModal");
const groundModal = document.getElementById("groundModal");
const firstModal = document.getElementById("firstModal");
const secondModal = document.getElementById("secondModal");

const academicPhoto = document.getElementById("academicPhoto");
const photoPlaceholder = document.getElementById("photoPlaceholder");
const academicDescription = document.getElementById("academicDescription");
const academicDirection = document.getElementById("academicDirection");

const groundText = document.getElementById("groundText");
const firstText = document.getElementById("firstText");

const roomPopup = document.getElementById("roomPopup");
const roomPopupTitle = document.getElementById("roomPopupTitle");
const roomPopupDescription = document.getElementById("roomPopupDescription");

/* --------------------------------------------------
   4. POPUP HELPERS
   -------------------------------------------------- */

function openModal(modal) {
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeModal(modal) {
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");

  const anyOpen =
    !academicModal.classList.contains("hidden") ||
    !groundModal.classList.contains("hidden") ||
    !firstModal.classList.contains("hidden") ||
    !secondModal.classList.contains("hidden");

  if (!anyOpen) {
    document.body.style.overflow = "";
  }
}

function closeAllModals() {
  [academicModal, groundModal, firstModal, secondModal]
    .forEach(closeModal);
}

/* --------------------------------------------------
   5. LOAD ACADEMIC BLOCK CONTENT
   -------------------------------------------------- */

document.getElementById("academicBlock").addEventListener("click", () => {
  academicDescription.textContent =
    academicInfo.description || "Add your Academic Block description in script.js.";

  academicDirection.textContent =
    academicInfo.direction || "Add directions here in script.js.";

  if (academicInfo.photo.trim() !== "") {
    academicPhoto.src = academicInfo.photo;
    academicPhoto.style.display = "block";
    photoPlaceholder.style.display = "none";
  } else {
    academicPhoto.removeAttribute("src");
    academicPhoto.style.display = "none";
    photoPlaceholder.style.display = "grid";
  }

  openModal(academicModal);
});

/* --------------------------------------------------
   6. FLOOR BUTTONS
   -------------------------------------------------- */

document.querySelectorAll(".floor-button").forEach((button) => {
  button.addEventListener("click", () => {
    const floor = button.dataset.floor;

    if (floor === "ground") {
      groundText.textContent = floorText.ground;
      openModal(groundModal);
    }

    if (floor === "first") {
      firstText.textContent = floorText.first;
      openModal(firstModal);
    }

    if (floor === "second") {
      openModal(secondModal);
    }
  });
});

/* --------------------------------------------------
   7. SECOND FLOOR ROOM HOTSPOTS
   -------------------------------------------------- */

document.querySelectorAll(".room-hotspot").forEach((button) => {
  button.addEventListener("click", () => {
    const room = roomData[button.dataset.room];

    if (!room) {
      return;
    }

    roomPopupTitle.textContent = room.title;
    roomPopupDescription.textContent =
      room.description || "Add a description in script.js.";

    roomPopup.classList.remove("hidden");
  });
});

document.getElementById("closeRoomPopup").addEventListener("click", () => {
  roomPopup.classList.add("hidden");
});

/* --------------------------------------------------
   8. CLOSE BUTTONS / BACKDROPS
   -------------------------------------------------- */

document.querySelectorAll("[data-close]").forEach((element) => {
  element.addEventListener("click", () => {
    const target = element.dataset.close;

    if (target === "academic") closeModal(academicModal);
    if (target === "ground") closeModal(groundModal);
    if (target === "first") closeModal(firstModal);
    if (target === "second") closeModal(secondModal);
  });
});

/* --------------------------------------------------
   9. ESC KEY
   -------------------------------------------------- */

document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") {
    return;
  }

  roomPopup.classList.add("hidden");

  if (!secondModal.classList.contains("hidden")) {
    closeModal(secondModal);
    return;
  }

  if (!firstModal.classList.contains("hidden")) {
    closeModal(firstModal);
    return;
  }

  if (!groundModal.classList.contains("hidden")) {
    closeModal(groundModal);
    return;
  }

  if (!academicModal.classList.contains("hidden")) {
    closeModal(academicModal);
  }
});
